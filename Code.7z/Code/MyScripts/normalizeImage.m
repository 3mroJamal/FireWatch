% Normalizes an image so that values fill the range [0,255]
% GrayScaleImage: Matrix of the GrayScale Image with depth = 1
function resultImage = normalizeImage(GrayScaleImage)
    ImageDouble = double(GrayScaleImage);
    maxValue =   prctile(ImageDouble(:),99.9);
    minValue =  prctile(ImageDouble(:),0.1);
    
    %%maxValue = max(max(ImageDouble));
    %%minValue = min(min(ImageDouble));
    ImageShiftedToZero = ImageDouble - minValue;
    resultImage = ImageShiftedToZero/(maxValue - minValue);
    resultImage(resultImage<0) = 0;
    resultImage(resultImage>1) = 1;
    
end